#!/bin/sh

java -cp storymode.jar:storymode_assets.jar core.common.SMRunner