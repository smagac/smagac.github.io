#/bin/sh

java -jar getdown-1.3.1.jar .