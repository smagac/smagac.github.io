#/bin/sh

java -jar boogie.jar